<?php
defined('is_running') or die('Not an entry point...');

$texts = array();
$texts[] = 'Search';
$texts[] = 'Sorry, there weren\'t any results for your search. ';


/* this function can be used to update the addon once changes to the text values have been made */
//function OnTextChange(){}
